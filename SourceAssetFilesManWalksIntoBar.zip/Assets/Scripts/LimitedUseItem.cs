using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LimitedUseItem : MonoBehaviour
{
    public bool canUse = true;
}
